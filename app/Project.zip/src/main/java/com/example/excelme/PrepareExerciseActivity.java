/*This class is responsible for fetching the data from the database into the application in sport menu
 * File: PrepareExerciseActivity.java
 * Author: Serdiuk Andrii
 * */


package com.example.excelme;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.jetbrains.annotations.NotNull;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class PrepareExerciseActivity extends AppCompatActivity {



    public final static long TEN_MEGABYTES = 10 * 1024 * 1024;
    public final static String DESCRIPTION = "/Exercise.txt";

    private FirebaseStorage storage;
    private StorageReference exercisesRef;
    private RecyclerView recyclerView;
    private SportListAdapter adapter;
    private final List<Exercise> exercises = new CopyOnWriteArrayList<>();
    static String complexity;
    static String type;
    private int amount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prepare_exercise);
        setWorkoutInformation();

        storage = FirebaseStorage.getInstance();

        exercisesRef = storage.getReference().child("exercises/" + type.toLowerCase() + "/" + complexity);

        Toast.makeText(this, exercisesRef.getName(), Toast.LENGTH_SHORT);

        bringDataFromDatabase();

        adapter = new SportListAdapter(this, exercises);
        recyclerView = findViewById(R.id.exercisesRecyclerView);

    }

    private void bringDataFromDatabase() {
        StringBuilder builder = new StringBuilder(100);
        for (int i = 1; i <= amount; i++) {
            int finalI = i;
            StorageReference ref = exercisesRef.child(i + DESCRIPTION);
            ref.getBytes(TEN_MEGABYTES).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                @Override
                public void onSuccess(byte[] bytes) {

                    String name, description;
                    int quantity;
                    BufferedReader reader =
                            new BufferedReader(new StringReader(new String(bytes, StandardCharsets.UTF_8)));
                    try {
                        name = reader.readLine();
                        byte n = Byte.parseByte(reader.readLine());
                        Toast.makeText(PrepareExerciseActivity.this, name + " " + n, Toast.LENGTH_SHORT).show();
                        for (byte j = 0; j < n; j++)
                            builder.append(reader.readLine()).append("\n");
                        description = builder.toString();
                        quantity = Integer.parseInt(reader.readLine());
                        adapter.addExercise(new Exercise(name, description, quantity, exercisesRef.child(finalI + "/Image.gif")));
                        Toast.makeText(PrepareExerciseActivity.this, "Added successfully", Toast.LENGTH_SHORT).show();
                    } catch (IOException | NumberFormatException ex) {
                        Toast.makeText(PrepareExerciseActivity.this, ex.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull @NotNull Exception e) {
                    Toast.makeText(PrepareExerciseActivity.this, "An error occurred fetching " + ref.getName(),
                            Toast.LENGTH_LONG).show();
                }
            });
        }
    }


    //Receiving data from SportChooseLevel fragment about current workout
    private void setWorkoutInformation() {

        switch (complexity) {
            case SportChooseLevel.COMPLEXITY_EASY:
                amount = SportChooseLevel.COMPLEXITY_EASY_AMOUNT;
                break;
            case SportChooseLevel.COMPLEXITY_MEDIUM:
                amount = SportChooseLevel.COMPLEXITY_MEDIUM_AMOUNT;
                break;
            case SportChooseLevel.COMPLEXITY_HARD:
                amount = SportChooseLevel.COMPLEXITY_HARD_AMOUNT;
                break;
            default:
                amount = -1;
                break;
        }

    }
}