/*This class is responsible for correct navigating from SportChooseLevel fragment
* to exercise preparation
* File: SportChooseLevel.java
* Author: Serdiuk Andrii
 */

package com.example.excelme;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentResultListener;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.card.MaterialCardView;

import org.jetbrains.annotations.NotNull;

public class SportChooseLevel extends Fragment {

    public static final String COMPLEXITY_EASY = "easy";
    public static final String COMPLEXITY_MEDIUM = "medium";
    public static final String COMPLEXITY_HARD = "hard";
    public static final int COMPLEXITY_EASY_AMOUNT = 4;
    public static final int COMPLEXITY_MEDIUM_AMOUNT = 5;
    public static final int COMPLEXITY_HARD_AMOUNT = 5;


    private String section;
    private Activity activity;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_sport_choose_level, container, false);
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        activity = getActivity();
        getParentFragmentManager().setFragmentResultListener("section", this, new FragmentResultListener() {
            @Override
            public void onFragmentResult(@NonNull @NotNull String requestKey, @NonNull @NotNull Bundle result) {
                SportChooseLevel.this.section = result.getString("section");
                ImageView easyIcon = view.findViewById(R.id.easy_icon);
                ImageView mediumIcon = view.findViewById(R.id.medium_icon);
                ImageView hardIcon = view.findViewById(R.id.hard_icon);
                MaterialCardView easyCard = view.findViewById(R.id.easyTrainingCard);
                MaterialCardView mediumCard = view.findViewById(R.id.mediumTrainingCard);
                MaterialCardView hardCard = view.findViewById(R.id.hardTrainingCard);
                easyCard.setOnClickListener(new WorkoutClickListener(COMPLEXITY_EASY));
                mediumCard.setOnClickListener(new WorkoutClickListener(COMPLEXITY_MEDIUM));
                hardCard.setOnClickListener(new WorkoutClickListener(COMPLEXITY_HARD));
                TextView workoutType = view.findViewById(R.id.workoutType);
                workoutType.setText(section + " WORKOUTS");
                switch (section) {
                    case "ABS":
                        easyIcon.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_abs_beginner));
                        mediumIcon.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_abs_medium));
                        hardIcon.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_abs_advanced));
                        break;
                    case "LEGS":
                        easyIcon.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_legs_beginner));
                        mediumIcon.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_legs_medium));
                        hardIcon.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_legs_advanced));
                        break;
                    case "FULL BODY":
                        easyIcon.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_full_body_beginner));
                        mediumIcon.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_full_body_medium));
                        hardIcon.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_full_body_advanced));
                        break;
                    case "ARMS":
                        easyIcon.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_arms_beginner));
                        mediumIcon.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_arms_medium));
                        hardIcon.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_arms_advanced));
                        break;
                    default:
                        Toast.makeText(activity, "An error occurred loading " + section + " messages", Toast.LENGTH_LONG).show();
                        break;
                }
            }
        });

    }

    private class WorkoutClickListener implements View.OnClickListener {

        private final String complexity;

        public WorkoutClickListener(String complexity) {
            this.complexity = complexity;
        }

        @Override
        public void onClick(View v) {

            Intent intent = new Intent(SportChooseLevel.this.activity, PrepareExerciseActivity.class);
            PrepareExerciseActivity.complexity = complexity;
            PrepareExerciseActivity.type = section;
            activity.startActivity(new Intent(activity, PrepareExerciseActivity.class));
        }
    }



}