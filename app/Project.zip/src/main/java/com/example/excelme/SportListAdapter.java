/*This class is responsible for displaying exercises in the window that starts the workout
 * File: SportListAdapter.java
 * Author: Serdiuk Andrii
 * */


package com.example.excelme;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class SportListAdapter extends RecyclerView.Adapter<SportListAdapter.SportViewHolder> {

        private Activity activity;
        private List<Exercise> exerciseList;

    public SportListAdapter(Activity activity, List<Exercise> exercises) {
        this.activity = activity;
        this.exerciseList = exercises;
    }

    public SportListAdapter() {}

    @NonNull
    @NotNull
    @Override
    public SportViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.exercise_list_item, parent,
                false);
        SportListAdapter.SportViewHolder holder = new SportListAdapter.SportViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull SportListAdapter.SportViewHolder holder, int position) {
        Exercise exercise = exerciseList.get(position);
        holder.name.setText(exercise.getName());
        holder.quantity.setText(exercise.getQuantity());
        exercise.getReference().getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                String s = uri.toString();
                Glide.with(activity).asGif().load(s).into(holder.image);
                exercise.setDownloadUrl(s);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull @NotNull Exception e) {
                Toast.makeText(activity, "An error occurred while fetching the image for exercise " + exercise.getName(),
                        Toast.LENGTH_LONG).show();
            }
        });
        //If the user clicks on the exercise image, they will see an expanded version of this exercise with instructions
        holder.image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, ExerciseExpandedActivity.class);
                String[] values = new String[4];
                values[0] = exercise.getName();
                values[1] = exercise.getDownloadUrl();
                values[2] = String.valueOf(exercise.getQuantity());
                values[3] = exercise.getDescription();
                intent.putExtra("recipe", values);
                activity.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return exerciseList.size();
    }

    public void addExercise(Exercise exercise) {
        exerciseList.add(exercise);
        notifyDataSetChanged();
    }


    public class SportViewHolder extends RecyclerView.ViewHolder {

        private TextView name;
        private ImageView image;
        private TextView quantity;

        public SportViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.exerciseName);
            image = itemView.findViewById(R.id.exerciseImage);
            quantity = itemView.findViewById(R.id.exerciseAmount);
        }
    }

}